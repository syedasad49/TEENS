from random import random, randint
from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.contrib import messages
from store.models.product import Product
from store.models.orders import Order
from django.views import View
from django.core.mail import send_mail
from twilio.rest import Client


class CheckOut(View):
    def generateRandomNumber(self):
        finalNumber = randint(1, 10000000000)
        return int(finalNumber)

    def sms(self, body, OrderNumber, mobile):
        account_sid = 'AC20079ad4b02a382d8b2e66dc324e463d'
        auth_token = '33631c80153f47a82d9fd8fe9945ddf6'
        client = Client(account_sid, auth_token)

        message = client.messages \
            .create(
            body= body,
            from_='+18189182512',
            to=mobile
        )

    def send(email_subject, msg, OrderNumber, recipient=[]):
        send_mail(subject=email_subject,
                  message= msg
                  , from_email='teensjewelry54@gmail.com'
                  , recipient_list=recipient
                  , fail_silently=False, )
        return True

    def post(self, request):
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customer')
        customer_info = Customer.get_customer_by_customerid(customer)

        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        list2d = []
        for product in products:
            order = Order(customer=Customer(id=customer), product=product, price=product.price, address=address,
                          mobile_no=mobile, quantity=cart.get(str(product.id)))
            list2d.append([])
            list2d[-1].append('Product: ' + str(product.name))
            list2d[-1].append('Price: ' + str(order.price))
            list2d[-1].append('Quantity: ' + str(order.quantity))
            order.placeOrder()
        request.session['cart'] = {}

        OrderNumber = self.generateRandomNumber()

        for i in range(len(list2d)):
            for j in range(i, len(list2d[0])):
                list2d[i][j] = list2d[i][j].replace("[","")
                #print(list2d[i][j])
        print(list2d)
        body = 'Hi ' + customer_info.first_name + ', \n\nYour order has been successfully placed.\n\nProduct Details:\n'+ str(list2d)+ '\n\nOrder Tracking Number: ' + str(
            OrderNumber) +'\n\nRegards, \nTEENS Jewelry and Ladies Shoes.'
        #CheckOut.send('TEENS Jewelry Order', 'Hi ' + customer_info.first_name + ', \n\nYour order has been successfully placed.\n\nProduct Details:\n'+ str(list2d)+ '\n\nOrder Tracking Number: ' + str(
        #             OrderNumber) +'\n\nRegards, \nTEENS Jewelry and Ladies Shoes.', OrderNumber, [customer_info.email])
        #
        # CheckOut.send('TEENS Jewelry-Customer Order', 'Hi, \n\n' + customer_info.first_name + '\'s order has been successfully placed. \n\nOrder Tracking Number: ' + str(
        #     OrderNumber) + '\n\nRegards, \nTEENS Jewelry and Ladies Shoes.', OrderNumber, ['syedasad49@yahoo.com','teensjewelry54@gmail.com'])
        #
        # if '+' in mobile and len(mobile) == 13:
        #
        #     self.sms("\nHi " + customer_info.first_name + ", \n\nYour order has been successfully placed. \n\nOrder Tracking Number: " + str(
        #     OrderNumber) + "\n\nRegards, \nTEENS Jewelry and Ladies Shoes.", OrderNumber, mobile)
        #
        #     self.sms("\nHi, \n\n" + customer_info.first_name + "\'s order has been successfully placed. \n\nOrder Tracking Number: " + str(
        #     OrderNumber) + "\n\nRegards, \nTEENS Jewelry and Ladies Shoes.", OrderNumber, '+923122899987')

        messages.success(request, 'Order successfully Placed!')
        return redirect('orders')
