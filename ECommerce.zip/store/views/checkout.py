import math
from random import random, randint
from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.contrib import messages
from store.models.product import Product
from store.models.orders import Order
from django.views import View
from django.core.mail import send_mail
from twilio.rest import Client


class CheckOut(View):
    def generateRandomNumber(digits):
        finalNumber = randint(1, 10000000000)
        return int(finalNumber)

    def sms(self, OrderNumber, mobile):
        account_sid = 'AC20079ad4b02a382d8b2e66dc324e463d'
        auth_token = '33631c80153f47a82d9fd8fe9945ddf6'
        client = Client(account_sid, auth_token)

        message = client.messages \
            .create(
            body="\nHi, \nYour order has been successfully placed. \n\nOrder Tracking Number: "+ str(OrderNumber)+
                 "\n\nRegards, \nTEENS Jewelry and Ladies Shoes.",
            from_='+18189182512',
            to=mobile
        )

    def send(email_subject, OrderNumber, recipient=[]):
        send_mail(subject=email_subject,
                  message='Hi, \n\nYour order has been successfully placed. \n\nOrder Tracking Number: '+ str(OrderNumber)+
                          '\n\nRegards, \nTEENS Jewelry and Ladies Shoes.'
                  , from_email='teensjewelry54@gmail.com'
                  , recipient_list=recipient
                  , fail_silently=False, )
        print(recipient)
        return True

    def post(self, request):
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customer')
        customer_email = request.session.get('customer_email')

        # customer = Customer.get_customer_by_customerid(customer.email)

        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        for product in products:
            order = Order(customer=Customer(id=customer), product=product, price=product.price, address=address,
                          mobile_no=mobile, quantity=cart.get(str(product.id)))
            order.placeOrder()
        request.session['cart'] = {}

        OrderNumber = CheckOut.generateRandomNumber(10)
        CheckOut.send('TEENS Jewelry Order', OrderNumber, [customer_email])
        CheckOut.send('TEENS Jewelry-Customer Order', OrderNumber, ['syedasad49@yahoo.com'])
        if '+' in mobile and len(mobile) == 13:
            self.sms(OrderNumber, mobile)
            self.sms(OrderNumber, '+923122899987')

        messages.success(request, 'Order successfully Placed!')
        return redirect('orders')
