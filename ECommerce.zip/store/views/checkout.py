import math
from random import random, randint
from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.contrib import messages
from store.models.product import Product
from store.models.orders import Order
from django.views import View
from django.core.mail import send_mail
from twilio.rest import Client


class CheckOut(View):
    def generateRandomNumber(self):
        finalNumber = randint(1, 10000000000)
        return int(finalNumber)

    def sms(self, customer_name, OrderNumber, mobile):
        account_sid = 'AC20079ad4b02a382d8b2e66dc324e463d'
        auth_token = '33631c80153f47a82d9fd8fe9945ddf6'
        client = Client(account_sid, auth_token)

        message = client.messages \
            .create(
            body="\nHi "+customer_name+", \nYour order has been successfully placed. \n\nOrder Tracking Number: "+ str(OrderNumber)+
                 "\n\nRegards, \nTEENS Jewelry and Ladies Shoes.",
            from_='+18189182512',
            to=mobile
        )

    def send(email_subject, customer_name, OrderNumber, recipient=[]):
        send_mail(subject=email_subject,
                  message='Hi '+customer_name+', \n\nYour order has been successfully placed. \n\nOrder Tracking Number: '+ str(OrderNumber)+
                          '\n\nRegards, \nTEENS Jewelry and Ladies Shoes.'
                  , from_email='teensjewelry54@gmail.com'
                  , recipient_list=recipient
                  , fail_silently=False, )
        print(recipient)
        return True

    def post(self, request):
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customer')
        customer_info = Customer.get_customer_by_customerid(customer)

        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        for product in products:
            order = Order(customer=Customer(id=customer), product=product, price=product.price, address=address,
                          mobile_no=mobile, quantity=cart.get(str(product.id)))
            order.placeOrder()
        request.session['cart'] = {}

        OrderNumber = self.generateRandomNumber()
        CheckOut.send('TEENS Jewelry Order', customer_info.first_name, OrderNumber, [customer_info.email])
        CheckOut.send('TEENS Jewelry-Customer Order', customer_info.first_name, OrderNumber, ['syedasad49@yahoo.com','teensjewelry54@gmail.com'])
        if '+' in mobile and len(mobile) == 13:
            self.sms(customer_info.first_name, OrderNumber, mobile)
            self.sms(customer_info.first_name, OrderNumber, '+923122899987')

        messages.success(request, 'Order successfully Placed!')
        return redirect('orders')
